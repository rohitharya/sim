# -*- coding: utf-8 -*-
"""
Created on Tue Jul 12 20:19:40 2022

@author: Admin
"""

a=3
b=5
print(a+b)

"""import math
from math import sin
a=1000
b=math.log10(a)
print(b)"""


"""import math     #to import the entire math library
from math import sin  #to import only on function from the math library 
x=90
y=math.sin(x)
print(y)"""


import math
from math import sin
x=90
x2=math.radians(x)
y=math.sin(x2)
print(y)